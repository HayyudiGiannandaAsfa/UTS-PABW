<?php
   $hostname  = "localhost";
   $username  = "gianmyid_hyd";
   $password  = "1234yogi322000";
   $dbname  = "gianmyid_uts";
   $db = new PDO('mysql:dbname='.$dbname.';host='.$hostname, $username, $password);
?>
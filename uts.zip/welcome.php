<?php
include('session.php');
?>
<body>
<h1>Welcome <?php echo $login_session; ?></h1>
<a href='logout.php'>logout</a>
</body>